// var bar = require("./bar")
// bar()


// import bar from "./bar"
// bar()

// import bar from "./bar"
// console.log(bar)
// console.log(bar.name)

// import {x,y,abs}  from "./bar"

// console.log(x,y,abs(2,3))

// import uu from "./bar"

// console.log(uu.x)

//将样式文件引入
import './css/style.css'