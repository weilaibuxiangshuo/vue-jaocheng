<template>
    <div>
        <p>app 根主键</p>
    </div>
</template>

<script>
export default {
    
}
</script>
